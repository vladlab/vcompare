<!--
  vcompare — main application shell.

  Analysis modes:
    - diff (default): fast pixel difference (blend + signalstats)
    - vmaf: perceptual quality (libvmaf)
-->

<script lang="ts">
  import { onMount, onDestroy } from "svelte";
  import { open, save } from "@tauri-apps/plugin-dialog";
  import {
    type AnalysisSummary,
    type FileProbe,
    type MetricSeries,
    type FrameResult,
    type Capabilities,
    type CacheCheck,
    type ProgressEvent,
    type DiagnosticsEvent,
    type UnlistenFn,
    ping,
    detectCapabilities,
    probeFile,
    checkCache,
    checkLevelsCache,
    loadSavedAnalysis,
    analyze,
    getMetricSeries,
    getFrames,
    exportCsv,
    getRecents,
    addRecent,
    type RecentEntry,
    mpvLaunch,
    mpvSeek,
    mpvStep,
    mpvTogglePause,
    mpvKill,
    diffviewLaunch,
    diffviewSeek,
    diffviewStep,
    diffviewPause,
    diffviewKill,
    onProgress,
    onDiagnostics,
    onMpvPosition,
    onDiffviewPosition,
  } from "./lib/rpc";
  import MetricChart from "./components/MetricChart.svelte";
  import FrameTable from "./components/FrameTable.svelte";
  import TimelineBar from "./components/TimelineBar.svelte";

  // ── App state ──

  type AppState = "idle" | "probing" | "analyzing" | "ready" | "error";

  let state: AppState = $state("idle");
  let errorMessage: string = $state("");

  // File selection
  let refPath: string = $state("");
  let distPath: string = $state("");
  let refProbe: FileProbe | null = $state(null);
  let distProbe: FileProbe | null = $state(null);
  let lastDir: string | undefined = $state(undefined);

  // Capabilities
  let caps: Capabilities | null = $state(null);

  // Cached analysis detection
  let cacheInfo: CacheCheck | null = $state(null);

  // Recent analyses
  let showRecents: boolean = $state(false);
  let recentEntries: RecentEntry[] = $state([]);

  // Analysis options
  let analysisMode: "diff" | "vmaf" | "levels" = $state("diff");
  let syncMode: string = $state("start");
  let hwaccelMode: string = $state("auto");
  let wantPsnr: boolean = $state(false);
  let wantSsim: boolean = $state(false);
  let subsample: number = $state(1);

  // Analysis results
  let summary: AnalysisSummary | null = $state(null);
  let metricSeries: Record<string, MetricSeries> = $state({});

  // Progress
  let progressCurrent: number = $state(0);
  let progressTotal: number = $state(0);
  let diagnosticLines: string[] = $state([]);

  // View state
  let activeMetric: string = $state("diff_y");
  let cursorFrame: number = $state(-1);
  let threshold: number | null = $state(null);

  // mpv state
  let mpvRunning: boolean = $state(false);
  let mpvAutoSeek: boolean = $state(false);
  let chartComponent: MetricChart | undefined = $state();
  let mpvFrame: number = $state(-1);

  // Difference view state
  let diffviewRunning: boolean = $state(false);
  let diffviewFrame: number = $state(-1);

  // Debounced seek — sends to both mpv instances if running
  let seekTimer: ReturnType<typeof setTimeout> | null = null;
  let seekGeneration = 0;

  function debouncedMpvSeek(frame: number) {
    if (!mpvRunning && !diffviewRunning) return;
    seekGeneration++;
    const gen = seekGeneration;
    if (seekTimer) clearTimeout(seekTimer);
    seekTimer = setTimeout(() => {
      if (gen === seekGeneration) {
        if (mpvRunning) mpvSeek(frame).catch(() => {});
        if (diffviewRunning) diffviewSeek(frame).catch(() => {});
      }
    }, 50);
  }

  // Event listener cleanup
  let unlisteners: UnlistenFn[] = [];

  // ── Lifecycle ──

  onMount(async () => {
    unlisteners.push(await onProgress(handleProgress));
    unlisteners.push(await onDiagnostics(handleDiagnostics));
    unlisteners.push(
      await onMpvPosition((e) => {
        mpvFrame = e.frame;
      })
    );

    const { listen } = await import("@tauri-apps/api/event");
    unlisteners.push(
      await listen("rpc:mpv-exited", () => {
        mpvRunning = false;
        mpvAutoSeek = false;
        mpvFrame = -1;
      })
    );

    unlisteners.push(
      await onDiffviewPosition((e) => {
        diffviewFrame = e.frame;
      })
    );
    unlisteners.push(
      await listen("rpc:diffview-exited", () => {
        diffviewRunning = false;
        diffviewFrame = -1;
      })
    );

    unlisteners.push(
      await listen("menu-event", (event) => {
        const id = event.payload as string;
        if (id === "new-analysis") {
          // Kill mpv instances if running
          mpvKill().catch(() => {});
          diffviewKill().catch(() => {});
          // Reset to idle
          state = "idle";
          refPath = "";
          distPath = "";
          refProbe = null;
          distProbe = null;
          cacheInfo = null;
          summary = null;
          metricSeries = {};
          progressCurrent = 0;
          progressTotal = 0;
          diagnosticLines = [];
          cursorFrame = -1;
          mpvRunning = false;
          mpvAutoSeek = false;
          mpvFrame = -1;
          diffviewRunning = false;
          diffviewFrame = -1;
          showRecents = false;
        } else if (id === "open-recent") {
          getRecents().then((entries) => {
            recentEntries = entries;
            showRecents = true;
          }).catch(() => {});
        }
      })
    );

    try {
      await ping();
      caps = await detectCapabilities();
    } catch (e) {
      state = "error";
      errorMessage = `Engine initialization failed: ${e}`;
    }
  });

  onDestroy(() => {
    unlisteners.forEach((fn) => fn());
  });

  // ── Bidirectional mpv sync ──
  $effect(() => {
    if (mpvAutoSeek && mpvFrame >= 0) {
      cursorFrame = mpvFrame;
    }
  });

  // ── File picking ──

  const VIDEO_FILTERS = [
    {
      name: "Video Files",
      extensions: [
        "mxf", "mov", "mp4", "mkv", "avi", "m4v", "mpg", "mpeg",
        "ts", "m2ts", "webm", "ogv", "mj2", "xml", "txt",
      ],
    },
    { name: "All Files", extensions: ["*"] },
  ];

  async function pickReference() {
    const result = await open({
      title: "Select reference video",
      filters: VIDEO_FILTERS,
      defaultPath: lastDir,
    });
    if (result) {
      refPath = result as string;
      lastDir = refPath.substring(0, refPath.lastIndexOf("/")) || undefined;
      try {
        refProbe = await probeFile(refPath);
      } catch (e) {
        refProbe = null;
      }
      if (analysisMode === "levels") {
        await updateCacheInfo();
      } else if (distPath) {
        await probeSelected();
      }
    }
  }

  async function pickDistorted() {
    const result = await open({
      title: "Select distorted video",
      filters: VIDEO_FILTERS,
      defaultPath: lastDir,
    });
    if (result) {
      distPath = result as string;
      lastDir = distPath.substring(0, distPath.lastIndexOf("/")) || undefined;
      try {
        distProbe = await probeFile(distPath);
      } catch (e) {
        distProbe = null;
      }
      if (refPath) await probeSelected();
    }
  }

  async function probeSelected() {
    if (!refPath || (!distPath && analysisMode !== "levels")) return;
    state = "probing";
    try {
      refProbe = await probeFile(refPath);
      if (distPath && analysisMode !== "levels") {
        distProbe = await probeFile(distPath);
      }
      await updateCacheInfo();
      state = "idle";
    } catch (e) {
      state = "error";
      errorMessage = `Probe failed: ${e}`;
    }
  }

  async function updateCacheInfo() {
    try {
      if (analysisMode === "levels" && refPath) {
        cacheInfo = await checkLevelsCache(refPath);
      } else if (refPath && distPath) {
        cacheInfo = await checkCache(refPath, distPath);
      } else {
        cacheInfo = null;
      }
    } catch {
      cacheInfo = null;
    }
  }

  // ── Analysis ──

  async function finishAnalysis(result: AnalysisSummary) {
    summary = result;
    metricSeries = {};

    // Fetch series for each available metric
    for (const m of result.metrics_available) {
      try {
        metricSeries[m] = await getMetricSeries(m);
      } catch (e) {
        console.error(`Failed to fetch series for ${m}:`, e);
      }
    }

    // Set active metric to first available
    if (result.metrics_available.length > 0) {
      activeMetric = result.metrics_available[0];
    }

    // Auto-set threshold
    if (result.mode === "diff" && result.diff_y_stats) {
      const s = result.diff_y_stats;
      threshold = Math.round((s.mean + (s.stddev ?? 0)) * 100) / 100;
    } else if (result.mode === "vmaf" && result.vmaf_stats) {
      const s = result.vmaf_stats;
      threshold = Math.round((s.mean - (s.stddev ?? 0)) * 100) / 100;
    } else if (result.mode === "levels") {
      // No threshold for levels by default
      threshold = null;
    }

    state = "ready";

    // Record in recents
    if (cacheInfo?.path && refPath) {
      addRecent({
        ref_path: refPath,
        dist_path: distPath || "",
        cache_path: cacheInfo.path,
        mode: result.mode,
        frame_count: result.frame_count,
        timestamp: Math.floor(Date.now() / 1000),
      }).catch(() => {});
    }
  }

  async function startAnalysis() {
    state = "analyzing";
    progressCurrent = 0;
    progressTotal = 0;
    diagnosticLines = [];

    try {
      const result = await analyze({
        reference: refPath,
        distorted: analysisMode !== "levels" ? distPath : undefined,
        mode: analysisMode,
        hwaccel: hwaccelMode,
        sync: syncMode,
        psnr: wantPsnr,
        ssim: wantSsim,
        subsample,
        log_path: cacheInfo?.path,
        force: true,
      });
      await finishAnalysis(result);
    } catch (e) {
      state = "error";
      errorMessage = `Analysis failed: ${e}`;
    }
  }

  async function loadCached() {
    if (!cacheInfo?.path) return;
    state = "analyzing";
    try {
      const result = await loadSavedAnalysis(cacheInfo.path);
      await finishAnalysis(result);
    } catch (e) {
      state = "error";
      errorMessage = `Failed to load cached analysis: ${e}`;
    }
  }

  async function loadRecentEntry(entry: RecentEntry) {
    showRecents = false;
    refPath = entry.ref_path;
    distPath = entry.dist_path;
    if (entry.mode === "levels" || entry.mode === "diff" || entry.mode === "vmaf") {
      analysisMode = entry.mode;
    }
    // Set cacheInfo so finishAnalysis can record it back to recents
    cacheInfo = { exists: true, path: entry.cache_path, frame_count: entry.frame_count, mode: entry.mode };
    state = "analyzing";
    try {
      const result = await loadSavedAnalysis(entry.cache_path);
      await finishAnalysis(result);
    } catch (e) {
      state = "error";
      errorMessage = `Failed to load recent analysis: ${e}`;
    }
  }

  // ── Event handlers ──

  function handleProgress(e: ProgressEvent) {
    progressCurrent = e.current;
    progressTotal = e.total;
  }

  function handleDiagnostics(e: DiagnosticsEvent) {
    diagnosticLines = e.lines;
  }

  function handleCursorChange(frame: number) {
    cursorFrame = frame;
    if (mpvRunning || diffviewRunning) {
      debouncedMpvSeek(frame);
    }
  }

  // ── Keyboard shortcuts ──

  function handleKeydown(e: KeyboardEvent) {
    if (state !== "ready") return;
    if ((e.target as HTMLElement)?.tagName === "INPUT") return;

    switch (e.key) {
      case "m":
        // Cycle through available metrics
        if (summary) {
          const avail = summary.metrics_available;
          const idx = avail.indexOf(activeMetric);
          activeMetric = avail[(idx + 1) % avail.length];
        }
        break;
      case "t":
        // Recalculate threshold from active metric stats
        // diff_* metrics: higher = worse (mean + σ)
        // ssim/vmaf/psnr: lower = worse (mean - σ)
        if (summary) {
          const statsKey = `${activeMetric}_stats` as keyof AnalysisSummary;
          const stats = summary[statsKey] as any;
          if (stats) {
            const higherIsWorse = activeMetric.startsWith("diff");
            if (higherIsWorse) {
              threshold = Math.round((stats.mean + (stats.stddev ?? 0)) * 100) / 100;
            } else {
              threshold = Math.round((stats.mean - (stats.stddev ?? 0)) * 100) / 100;
            }
          }
        }
        break;
      case "T":
        threshold = null;
        break;
      case "p":
        if (!mpvRunning) {
          mpvLaunch().then(() => (mpvRunning = true)).catch(() => {});
        }
        break;
      case "P":
        mpvKill().then(() => (mpvRunning = false));
        break;
      case "d":
        if (!diffviewRunning) {
          diffviewLaunch().then(() => (diffviewRunning = true)).catch((e) => console.error("diffview:", e));
        }
        break;
      case "D":
        diffviewKill().then(() => (diffviewRunning = false));
        break;
      case "s":
        if (cursorFrame >= 0) {
          if (mpvRunning) mpvSeek(cursorFrame);
          if (diffviewRunning) diffviewSeek(cursorFrame);
        }
        break;
      case "a":
        mpvAutoSeek = !mpvAutoSeek;
        break;
      case ".":
        if (mpvRunning) mpvStep("forward");
        if (diffviewRunning) diffviewStep("forward");
        break;
      case ",":
        if (mpvRunning) mpvStep("backward");
        if (diffviewRunning) diffviewStep("backward");
        break;
      case " ":
        if (mpvRunning || diffviewRunning) {
          e.preventDefault();
          if (mpvRunning) mpvTogglePause();
          if (diffviewRunning) diffviewPause();
        }
        break;
      case "e":
        handleExport();
        break;
      case "f": {
        const idx = SMOOTH_OPTIONS.indexOf(smoothWindow);
        smoothWindow = SMOOTH_OPTIONS[(idx + 1) % SMOOTH_OPTIONS.length];
        break;
      }
      case "=":
      case "+":
        chartComponent?.zoomIn();
        break;
      case "-":
        chartComponent?.zoomOut();
        break;
      case "0":
        chartComponent?.zoomReset();
        break;
    }
  }

  async function handleExport() {
    const result = await save({
      title: "Export CSV",
      defaultPath: "vcompare_export.csv",
      filters: [{ name: "CSV", extensions: ["csv"] }],
    });
    if (result) {
      await exportCsv(result as string);
    }
  }

  // ── Derived values ──

  let progressPct = $derived(
    progressTotal > 0 ? Math.round((progressCurrent / progressTotal) * 100) : 0
  );

  let activeSeries = $derived(metricSeries[activeMetric] ?? null);

  // ── Temporal smoothing (running median) ──

  let smoothWindow: number = $state(0); // 0 = off, otherwise odd window size
  const SMOOTH_OPTIONS = [0, 5, 11, 21, 51]; // off, light, medium, heavy, very heavy

  function runningMedian(values: number[], window: number): number[] {
    if (window <= 1) return values;
    const half = (window - 1) / 2;
    const result = new Array(values.length);
    for (let i = 0; i < values.length; i++) {
      const lo = Math.max(0, i - half);
      const hi = Math.min(values.length - 1, i + half);
      const slice = values.slice(lo, hi + 1);
      slice.sort((a, b) => a - b);
      result[i] = slice[Math.floor(slice.length / 2)];
    }
    return result;
  }

  let displaySeries = $derived.by(() => {
    if (!activeSeries) return null;
    if (smoothWindow <= 1) return activeSeries;
    return {
      frames: activeSeries.frames,
      values: runningMedian(activeSeries.values, smoothWindow),
    };
  });

  let activeStats = $derived(() => {
    if (!summary) return null;
    const key = `${activeMetric}_stats` as keyof AnalysisSummary;
    return (summary[key] as any) ?? null;
  });

  function fmtProbe(p: FileProbe | null): string {
    if (!p) return "—";
    const fps = p.fps_den === 1001
      ? `${(p.fps_num / p.fps_den).toFixed(2)}`
      : `${p.fps_num / p.fps_den}`;
    const tc = p.timecode ? ` TC ${p.timecode}` : "";
    return `${p.width}×${p.height} ${p.codec} ${p.pix_fmt} ${fps}fps${tc}`;
  }

  function fmtMetricLabel(m: string): string {
    const labels: Record<string, string> = {
      diff_y: "Diff Y",
      diff_u: "Diff U",
      diff_v: "Diff V",
      ssim: "SSIM",
      ssim_y: "SSIM Y",
      ssim_u: "SSIM U",
      ssim_v: "SSIM V",
      vmaf: "VMAF",
      psnr: "PSNR",
      y_min: "Y Min",
      y_max: "Y Max",
      u_min: "U Min",
      u_max: "U Max",
      v_min: "V Min",
      v_max: "V Max",
    };
    return labels[m] ?? m;
  }
</script>

<svelte:window onkeydown={handleKeydown} />

<div class="app">
  <!-- ── Header bar ── -->
  <header class="header">
    <span class="header-title">vcompare</span>
    {#if state === "ready" && summary}
      <span class="header-badge">{summary.mode}</span>
      <span class="header-meta mono">
        {summary.frame_count.toLocaleString()} frames
        {#if summary.tc_format}
          · {summary.tc_format.fps_num}/{summary.tc_format.fps_den}fps
        {/if}
        {#if activeStats()}
          · {fmtMetricLabel(activeMetric)}
          μ={activeStats().mean.toFixed(activeMetric.startsWith("ssim") ? 4 : 0)}
          {#if summary.mode === "levels"}
            range={activeStats().min.toFixed(0)}–{activeStats().max.toFixed(0)}
          {:else}
            {activeMetric.startsWith("diff") ? "max" : "min"}={activeMetric.startsWith("diff") ? activeStats().max.toFixed(2) : activeStats().min.toFixed(activeMetric.startsWith("ssim") ? 4 : 2)}
          {/if}
        {/if}
      </span>
      {#if summary.mode === "diff" && summary.diff_distribution}
        <span class="header-meta mono">
          · {summary.diff_distribution.zero} identical
          · {summary.diff_distribution.above_10} major
        </span>
      {/if}
    {/if}
    {#if mpvRunning}
      <span class="header-badge">mpv</span>
      <span class="header-meta mono">
        sync={mpvAutoSeek ? "bidi" : "fwd"}
      </span>
    {/if}
  </header>

  <!-- ── Main content ── -->
  <main class="main">

    {#if state === "idle" || state === "probing"}
      <!-- File picker panel -->
      <div class="picker-panel">
        <div class="picker-section">
          <h2>{analysisMode === "levels" ? "Analyze Video" : "Compare Videos"}</h2>
          <p class="text-secondary">
            {analysisMode === "levels"
              ? "Select a video file to analyze signal levels."
              : "Select a reference and distorted file to compare."}
          </p>
        </div>

        <div class="options-row" style="margin-bottom: 12px;">
          <label>
            Mode
            <select bind:value={analysisMode} onchange={() => updateCacheInfo()}>
              <option value="diff">Pixel Diff</option>
              <option value="vmaf">VMAF</option>
              <option value="levels">Levels</option>
            </select>
          </label>
        </div>

        <div class="file-row">
          <label>{analysisMode === "levels" ? "File" : "Reference"}</label>
          <button onclick={pickReference} class="file-btn" title={refPath || ""}>
            {refPath ? refPath.split("/").pop() : "Choose file…"}
          </button>
          {#if refProbe}
            <span class="file-meta mono">{fmtProbe(refProbe)}</span>
          {/if}
        </div>

        {#if analysisMode !== "levels"}
          <div class="file-row">
            <label>Distorted</label>
            <button onclick={pickDistorted} class="file-btn" title={distPath || ""}>
              {distPath ? distPath.split("/").pop() : "Choose file…"}
            </button>
            {#if distProbe}
              <span class="file-meta mono">{fmtProbe(distProbe)}</span>
            {/if}
          </div>
        {/if}

        {#if analysisMode === "levels" && refProbe}
          <button class="primary analyze-btn" onclick={startAnalysis}>
            {cacheInfo?.exists ? "Re-analyze" : "Analyze"}
          </button>

          {#if cacheInfo?.exists}
            <div class="cache-row">
              <span class="cache-info mono">
                Cached (levels): {cacheInfo.frame_count?.toLocaleString()} frames
                ({cacheInfo.path.split("/").pop()})
              </span>
              <button class="primary" onclick={loadCached}>
                Load cached
              </button>
            </div>
          {/if}
        {:else if analysisMode !== "levels" && refProbe && distProbe}
          {#if Math.abs(refProbe.fps - distProbe.fps) > 0.01}
            <div class="fps-warning">
              ⚠ Framerate mismatch: ref {refProbe.fps_num}/{refProbe.fps_den} ({refProbe.fps.toFixed(3)}fps) vs dist {distProbe.fps_num}/{distProbe.fps_den} ({distProbe.fps.toFixed(3)}fps) — results may be unreliable
            </div>
          {/if}
          <div class="options-row">
            <label>
              Sync
              <select bind:value={syncMode}>
                <option value="start">Start-aligned</option>
                <option value="tc">Timecode</option>
              </select>
            </label>
            {#if analysisMode === "vmaf"}
              <label>
                HW Accel
                <select bind:value={hwaccelMode}>
                  <option value="auto">Auto{caps?.hwaccel ? ` (${caps.hwaccel})` : ""}</option>
                  <option value="cuda">CUDA</option>
                  <option value="vaapi">VAAPI</option>
                  <option value="none">None</option>
                </select>
              </label>
              <label class="checkbox-label">
                <input type="checkbox" bind:checked={wantPsnr} />
                PSNR
              </label>
              <label>
                Subsample
                <select bind:value={subsample}>
                  <option value={1}>1× (every frame)</option>
                  <option value={2}>2×</option>
                  <option value={4}>4×</option>
                  <option value={8}>8×</option>
                </select>
              </label>
            {:else}
              <label class="checkbox-label">
                <input type="checkbox" bind:checked={wantSsim} />
                SSIM
              </label>
            {/if}
          </div>

          <button class="primary analyze-btn" onclick={startAnalysis}>
            {cacheInfo?.exists ? "Re-analyze" : "Analyze"}
          </button>

          {#if cacheInfo?.exists}
            <div class="cache-row">
              <span class="cache-info mono">
                Cached ({cacheInfo.mode ?? "vmaf"}{cacheInfo.with_ssim ? "+ssim" : ""}, {cacheInfo.sync_mode ?? "start"}): {cacheInfo.frame_count?.toLocaleString()} frames
                ({cacheInfo.path.split("/").pop()})
              </span>
              <button class="primary" onclick={loadCached}>
                Load cached
              </button>
            </div>
          {/if}
        {/if}
      </div>

    {:else if state === "analyzing"}
      <!-- Progress view -->
      <div class="progress-panel">
        <h2>Analyzing… ({analysisMode === "diff" ? "pixel diff" : analysisMode === "levels" ? "levels" : "VMAF"})</h2>
        <div class="progress-bar-container">
          <div class="progress-bar" style="width: {progressPct}%"></div>
        </div>
        <div class="progress-label mono">
          {#if progressTotal > 0}
            {progressCurrent.toLocaleString()} / {progressTotal.toLocaleString()} frames
            ({progressPct}%)
          {:else}
            Starting FFmpeg…
          {/if}
        </div>
        {#if diagnosticLines.length > 0}
          <pre class="diagnostics mono">{diagnosticLines.join("\n")}</pre>
        {/if}
      </div>

    {:else if state === "ready" && activeSeries}
      <!-- Results view -->
      <div class="results-layout">
        {#if summary?.timeline}
          <TimelineBar
            timeline={summary.timeline}
            tcFormat={summary.tc_format}
          />
        {/if}
        <div class="chart-area">
          <MetricChart
            bind:this={chartComponent}
            series={displaySeries}
            metric={activeMetric}
            {threshold}
            {cursorFrame}
            onCursorChange={handleCursorChange}
            timeline={summary?.timeline}
          />
        </div>
        <div class="table-area">
          <FrameTable
            {cursorFrame}
            metrics={summary?.metrics_available ?? []}
            mode={summary?.mode ?? "diff"}
            onFrameSelect={handleCursorChange}
          />
        </div>
      </div>

    {:else if state === "error"}
      <div class="error-panel">
        <h2 class="text-error">Error</h2>
        <pre class="error-message mono">{errorMessage}</pre>
        <button onclick={() => (state = "idle")}>Back</button>
      </div>
    {/if}
  </main>

  <!-- ── Footer ── -->
  {#if state === "ready"}
    <footer class="footer">
      <span class="footer-shortcuts">
        <kbd>m</kbd> metric
        <kbd>t</kbd> threshold
        <kbd>f</kbd> smooth{smoothWindow > 0 ? ` (${smoothWindow})` : ""}
        <kbd>e</kbd> export
        <kbd>+</kbd><kbd>-</kbd> zoom
        <kbd>0</kbd> reset
        <kbd>p</kbd> mpv
        <kbd>d</kbd> diff
        <kbd>s</kbd> seek
        <kbd>a</kbd> sync {mpvAutoSeek ? "↔ bidi" : "→ fwd"}
        <kbd>.</kbd><kbd>,</kbd> step
        <kbd>space</kbd> pause
      </span>
    </footer>
  {/if}
</div>

<!-- ── Recents overlay ── -->
{#if showRecents}
  <div class="recents-overlay" onclick={() => (showRecents = false)}>
    <div class="recents-panel" onclick={(e) => e.stopPropagation()}>
      <div class="recents-header">
        <h3>Recent Analyses</h3>
        <button class="recents-close" onclick={() => (showRecents = false)}>✕</button>
      </div>
      {#if recentEntries.length === 0}
        <p class="recents-empty">No recent analyses</p>
      {:else}
        <div class="recents-list">
          {#each recentEntries as entry}
            <button
              class="recents-entry"
              onclick={() => loadRecentEntry(entry)}
            >
              <span class="recents-files mono">
                {entry.ref_path.split("/").pop()}{entry.dist_path ? ` vs ${entry.dist_path.split("/").pop()}` : ""}
              </span>
              <span class="recents-meta">
                {entry.mode} · {entry.frame_count.toLocaleString()} frames · {new Date(entry.timestamp * 1000).toLocaleDateString()}
              </span>
            </button>
          {/each}
        </div>
      {/if}
    </div>
  </div>
{/if}

<style>
  .app {
    display: flex;
    flex-direction: column;
    height: 100vh;
    overflow: hidden;
  }

  .header {
    display: flex;
    align-items: center;
    gap: var(--gap-md);
    padding: 6px var(--gap-lg);
    background: var(--bg-surface);
    border-bottom: 1px solid var(--border-subtle);
    min-height: 34px;
    flex-shrink: 0;
  }
  .header-title {
    font-weight: 600;
    font-size: 14px;
    letter-spacing: 0.02em;
  }
  .header-meta {
    color: var(--text-secondary);
    font-size: 11px;
  }
  .header-badge {
    font-size: 10px;
    font-weight: 600;
    padding: 1px 6px;
    border-radius: 3px;
    background: var(--accent-dim);
    color: #fff;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }

  .main {
    flex: 1;
    overflow: hidden;
    display: flex;
    align-items: stretch;
  }

  /* File picker */
  .picker-panel {
    max-width: 560px;
    margin: auto;
    padding: var(--gap-xl);
    display: flex;
    flex-direction: column;
    gap: var(--gap-lg);
  }
  .picker-section h2 {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: var(--gap-xs);
  }
  .file-row {
    display: flex;
    align-items: center;
    gap: var(--gap-md);
  }
  .file-row label {
    width: 80px;
    font-weight: 500;
    color: var(--text-secondary);
    text-align: right;
    flex-shrink: 0;
  }
  .file-btn {
    min-width: 200px;
    max-width: 300px;
    text-align: left;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .file-meta {
    color: var(--text-muted);
    font-size: 11px;
    white-space: nowrap;
  }
  .fps-warning {
    color: #e8a020;
    font-size: 12px;
    padding: 6px 10px;
    background: rgba(232, 160, 32, 0.08);
    border: 1px solid rgba(232, 160, 32, 0.25);
    border-radius: 4px;
  }
  .options-row {
    display: flex;
    gap: var(--gap-lg);
    align-items: center;
    flex-wrap: wrap;
  }
  .options-row label {
    display: flex;
    align-items: center;
    gap: var(--gap-xs);
    color: var(--text-secondary);
    font-size: 12px;
  }
  .options-row select {
    font-family: var(--font-ui);
    font-size: 12px;
    padding: 3px 6px;
    background: var(--bg-raised);
    border: 1px solid var(--border-default);
    border-radius: var(--radius-sm);
    color: var(--text-primary);
  }
  .checkbox-label {
    cursor: pointer;
  }
  .analyze-btn {
    align-self: flex-end;
    padding: 8px 24px;
    font-size: 14px;
  }
  .cache-row {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: var(--gap-md);
  }
  .cache-info {
    color: var(--text-secondary);
    font-size: 11px;
  }

  /* Progress */
  .progress-panel {
    max-width: 560px;
    margin: auto;
    padding: var(--gap-xl);
    display: flex;
    flex-direction: column;
    gap: var(--gap-md);
  }
  .progress-panel h2 {
    font-size: 16px;
    font-weight: 600;
  }
  .progress-bar-container {
    width: 100%;
    height: 6px;
    background: var(--bg-overlay);
    border-radius: 3px;
    overflow: hidden;
  }
  .progress-bar {
    height: 100%;
    background: var(--vmaf-color);
    transition: width 0.2s ease;
    border-radius: 3px;
  }
  .progress-label {
    color: var(--text-secondary);
    font-size: 12px;
  }
  .diagnostics {
    font-size: 11px;
    color: var(--text-muted);
    background: var(--bg-raised);
    padding: var(--gap-sm);
    border-radius: var(--radius-sm);
    overflow: auto;
    max-height: 200px;
    white-space: pre-wrap;
  }

  /* Results */
  .results-layout {
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }
  .chart-area {
    flex: 0 0 45%;
    min-height: 200px;
    border-bottom: 1px solid var(--border-subtle);
  }
  .table-area {
    flex: 1;
    overflow: hidden;
  }

  /* Error */
  .error-panel {
    max-width: 560px;
    margin: auto;
    padding: var(--gap-xl);
    display: flex;
    flex-direction: column;
    gap: var(--gap-md);
  }
  .error-message {
    font-size: 12px;
    color: var(--threshold-color);
    background: var(--bg-raised);
    padding: var(--gap-sm);
    border-radius: var(--radius-sm);
    overflow: auto;
    max-height: 300px;
    white-space: pre-wrap;
  }

  /* Footer */
  .footer {
    display: flex;
    align-items: center;
    padding: 4px var(--gap-lg);
    background: var(--bg-surface);
    border-top: 1px solid var(--border-subtle);
    min-height: 28px;
    flex-shrink: 0;
  }
  .footer-shortcuts {
    font-size: 11px;
    color: var(--text-muted);
    display: flex;
    gap: var(--gap-sm);
    align-items: center;
    flex-wrap: wrap;
  }
  .recents-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.6);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 100;
  }
  .recents-panel {
    background: var(--bg-surface, #1e1e1e);
    border: 1px solid var(--border, rgba(255,255,255,0.1));
    border-radius: 8px;
    width: min(600px, 90vw);
    max-height: 70vh;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }
  .recents-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 16px;
    border-bottom: 1px solid var(--border, rgba(255,255,255,0.1));
  }
  .recents-header h3 {
    margin: 0;
    font-size: 14px;
  }
  .recents-close {
    background: none;
    border: none;
    color: var(--text-muted);
    font-size: 16px;
    cursor: pointer;
    padding: 4px 8px;
  }
  .recents-close:hover {
    color: var(--text);
  }
  .recents-empty {
    padding: 24px;
    text-align: center;
    color: var(--text-muted);
  }
  .recents-list {
    overflow-y: auto;
    padding: 4px;
  }
  .recents-entry {
    display: flex;
    flex-direction: column;
    gap: 2px;
    width: 100%;
    padding: 10px 12px;
    text-align: left;
    background: none;
    border: none;
    border-radius: 4px;
    color: var(--text);
    cursor: pointer;
  }
  .recents-entry:hover {
    background: rgba(255, 255, 255, 0.06);
  }
  .recents-files {
    font-size: 12px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .recents-meta {
    font-size: 11px;
    color: var(--text-muted);
  }
</style>
