//! mpv controller — manages an mpv instance with JSON IPC.
//!
//! Uses Unix domain sockets for frame-accurate seeking and position polling.
//! Ported from vcompare.py's MpvController class.

use serde_json::Value;
use std::io::{BufRead, BufReader, Write};
use std::os::unix::net::UnixStream;
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::sync::Mutex;
use std::time::Duration;

use crate::engine::timecode::TimecodeFormat;

/// mpv process controller with IPC.
pub struct MpvController {
    ref_path: String,
    dist_path: String,
    tc_format: TimecodeFormat,
    ref_file_start_tc: i64,
    process: Mutex<Option<Child>>,
    sock_path: PathBuf,
}

impl MpvController {
    pub fn new(
        ref_path: String,
        dist_path: String,
        tc_format: TimecodeFormat,
        ref_file_start_tc: i64,
    ) -> Self {
        let sock_path = std::env::temp_dir().join(format!(
            "vcompare_mpv_{}.sock",
            std::process::id()
        ));
        Self {
            ref_path,
            dist_path,
            tc_format,
            ref_file_start_tc,
            process: Mutex::new(None),
            sock_path,
        }
    }

    /// Check if the mpv process is still running.
    pub fn is_running(&self) -> bool {
        let mut proc = self.process.lock().unwrap();
        match proc.as_mut() {
            Some(p) => p.try_wait().ok().flatten().is_none(),
            None => false,
        }
    }

    /// Launch mpv with side-by-side view. Returns error string or None.
    pub fn launch(&self) -> Option<String> {
        if self.is_running() {
            return Some("mpv already running".into());
        }

        // Clean up any stale socket
        let _ = std::fs::remove_file(&self.sock_path);

        let ref_name = Path::new(&self.ref_path)
            .file_name()
            .map(|n| n.to_string_lossy().to_string())
            .unwrap_or_default();
        let dist_name = Path::new(&self.dist_path)
            .file_name()
            .map(|n| n.to_string_lossy().to_string())
            .unwrap_or_default();

        let lavfi = "[vid1][vid2]hstack[vo]";
        let sock_str = self.sock_path.to_string_lossy().to_string();

        let cmd_result = Command::new("mpv")
            .arg(&self.ref_path)
            .arg(format!("--external-file={}", self.dist_path))
            .arg(format!("--lavfi-complex={lavfi}"))
            .arg(format!("--input-ipc-server={sock_str}"))
            .arg("--pause")
            .arg("--hr-seek=yes")
            .arg("--keep-open=yes")
            .arg("--force-window=yes")
            .arg("--osd-level=2")
            .arg("--osd-fractions")
            .arg(format!("--title=vcompare: {ref_name} | {dist_name}"))
            .arg("--no-terminal")
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .spawn();

        match cmd_result {
            Ok(child) => {
                *self.process.lock().unwrap() = Some(child);
            }
            Err(_) => return Some("mpv not found in PATH".into()),
        }

        // Wait for IPC socket to appear (up to 5 seconds)
        for _ in 0..50 {
            if self.sock_path.exists() {
                return None; // Success
            }
            std::thread::sleep(Duration::from_millis(100));
        }

        Some("mpv started but IPC socket not ready (timeout)".into())
    }

    /// Send a JSON IPC command to mpv and return the response.
    fn send_command(&self, args: &[&str]) -> Option<Value> {
        if !self.is_running() {
            return None;
        }

        let msg = serde_json::json!({"command": args});
        let msg_str = format!("{}\n", serde_json::to_string(&msg).ok()?);

        let mut stream = UnixStream::connect(&self.sock_path).ok()?;
        stream
            .set_read_timeout(Some(Duration::from_secs(2)))
            .ok()?;
        stream.write_all(msg_str.as_bytes()).ok()?;

        // Read response (one line)
        let mut reader = BufReader::new(stream);
        let mut response = String::new();
        reader.read_line(&mut response).ok()?;

        serde_json::from_str(&response).ok()
    }

    /// Send a command with mixed argument types.
    fn send_command_val(&self, args: Vec<Value>) -> Option<Value> {
        if !self.is_running() {
            return None;
        }

        let msg = serde_json::json!({"command": args});
        let msg_str = format!("{}\n", serde_json::to_string(&msg).ok()?);

        let mut stream = UnixStream::connect(&self.sock_path).ok()?;
        stream
            .set_read_timeout(Some(Duration::from_secs(2)))
            .ok()?;
        stream.write_all(msg_str.as_bytes()).ok()?;

        let mut reader = BufReader::new(stream);
        let mut response = String::new();
        reader.read_line(&mut response).ok()?;

        serde_json::from_str(&response).ok()
    }

    /// Seek mpv to a display frame number (absolute TC frame).
    pub fn seek_to_frame(&self, frame_num: i64) -> bool {
        if !self.is_running() {
            return false;
        }
        // Convert absolute TC frame → file-relative seconds
        let file_frame = frame_num - self.ref_file_start_tc;
        let seconds = (file_frame as f64 / self.tc_format.fps_float()).max(0.0);
        let result = self.send_command_val(vec![
            "set_property".into(),
            "time-pos".into(),
            serde_json::json!(seconds),
        ]);
        result.is_some()
    }

    /// Get mpv's current position as a display frame number.
    pub fn get_frame(&self) -> Option<i64> {
        if !self.is_running() {
            return None;
        }
        let result = self.send_command(&["get_property", "time-pos"])?;
        let seconds = result.get("data")?.as_f64()?;
        let file_frame = (seconds * self.tc_format.fps_float()).round() as i64;
        Some(file_frame + self.ref_file_start_tc)
    }

    /// Step one frame forward.
    pub fn step_forward(&self) -> bool {
        self.send_command(&["frame-step"]).is_some()
    }

    /// Step one frame backward.
    pub fn step_backward(&self) -> bool {
        self.send_command(&["frame-back-step"]).is_some()
    }

    /// Toggle play/pause.
    pub fn toggle_pause(&self) -> bool {
        self.send_command(&["cycle", "pause"]).is_some()
    }

    /// Terminate mpv and clean up.
    pub fn kill(&self) {
        // Try graceful quit first
        let _ = self.send_command(&["quit"]);

        let mut proc = self.process.lock().unwrap();
        if let Some(ref mut child) = *proc {
            // Wait briefly for graceful exit
            match child.try_wait() {
                Ok(Some(_)) => {}
                _ => {
                    std::thread::sleep(Duration::from_secs(1));
                    match child.try_wait() {
                        Ok(Some(_)) => {}
                        _ => {
                            let _ = child.kill();
                            let _ = child.wait();
                        }
                    }
                }
            }
        }
        *proc = None;

        // Clean up socket
        let _ = std::fs::remove_file(&self.sock_path);
    }
}

impl Drop for MpvController {
    fn drop(&mut self) {
        self.kill();
    }
}
