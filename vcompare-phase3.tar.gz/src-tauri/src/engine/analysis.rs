//! Analysis engine — diff and VMAF analysis via ffmpeg.
//!
//! Ports the core analysis pipeline from vcompare.py and vcompare_engine.py.
//! Spawns ffmpeg as a subprocess, streams stderr for progress, parses results.

use regex::Regex;
use serde_json::Value;
use std::collections::VecDeque;
use std::io::{BufReader, Read};
use std::process::{Child, Command, Stdio};
use std::sync::{Arc, Mutex};
use std::time::Instant;

use crate::engine::pixfmt::choose_common_pixfmt;
use crate::engine::probe::{ffprobe_json, get_video_info, is_concat_manifest};
use crate::engine::timecode::{detect_timecode_format, TimecodeFormat};
use crate::engine::types::ComparisonConfig;

/// Callback for progress updates: (current_frame, total_frames).
pub type ProgressFn = Box<dyn Fn(u64, u64) + Send>;

/// Handle to a running ffmpeg process for external cancellation.
pub type ProcessHandle = Arc<Mutex<Option<Child>>>;

// ─── Prepare comparison ─────────────────────────────────────────────────────

/// Probe both files and compute trim/scale/format parameters.
///
/// This is the shared setup for both diff and vmaf analysis modes.
pub fn prepare_comparison(
    ref_path: &str,
    dist_path: &str,
    sync_mode: &str,
    vmaf_cuda: bool,
    offset_frames: i64,
    diagnostics: &mut Vec<String>,
) -> Result<(ComparisonConfig, TimecodeFormat), String> {
    let ref_probe = ffprobe_json(ref_path)?;
    let dist_probe = ffprobe_json(dist_path)?;

    let tc_fmt = detect_timecode_format(&ref_probe)?;
    let ref_info = get_video_info(&ref_probe, &tc_fmt)?;
    let dist_info = get_video_info(&dist_probe, &tc_fmt)?;

    let mut config = ComparisonConfig::default();
    config.ref_file_start_tc = ref_info.start_tc_frames;
    config.use_vmaf_cuda = vmaf_cuda;
    config.ref_src_pixfmt = ref_info.pix_fmt.clone();
    config.dist_src_pixfmt = dist_info.pix_fmt.clone();

    diagnostics.push(format!(
        "ref: {}x{} {} {}/{}",
        ref_info.width, ref_info.height, ref_info.pix_fmt, ref_info.fps_num, ref_info.fps_den
    ));
    diagnostics.push(format!(
        "dist: {}x{} {} {}/{}",
        dist_info.width, dist_info.height, dist_info.pix_fmt, dist_info.fps_num, dist_info.fps_den
    ));

    // Resolution scaling — scale distorted to match reference
    if ref_info.width != dist_info.width || ref_info.height != dist_info.height {
        config.scale_w = ref_info.width;
        config.scale_h = ref_info.height;
        diagnostics.push(format!(
            "resolution: MISMATCH → scaling dist to {}x{}",
            ref_info.width, ref_info.height
        ));
    } else {
        diagnostics.push(format!(
            "resolution: matched ({}x{})",
            ref_info.width, ref_info.height
        ));
    }

    // Pixel format negotiation (for vmaf — diff overrides this)
    let neg = choose_common_pixfmt(&ref_info.pix_fmt, &dist_info.pix_fmt);
    config.ref_pixfmt = neg.ref_convert;
    config.dist_pixfmt = neg.dist_convert;

    if config.ref_pixfmt.is_some() || config.dist_pixfmt.is_some() {
        diagnostics.push(format!(
            "pixfmt: {} vs {} → target {}",
            ref_info.pix_fmt, dist_info.pix_fmt, neg.target
        ));
    } else {
        diagnostics.push(format!(
            "pixfmt: matched ({}, no conversion)",
            ref_info.pix_fmt
        ));
    }

    diagnostics.push(format!("sync: {sync_mode}"));

    // TC sync
    if sync_mode == "tc" {
        let ref_start = ref_info.start_tc_frames;
        let dist_start = dist_info.start_tc_frames;

        if ref_start != dist_start {
            let overlap_start = ref_start.max(dist_start);
            config.ref_trim_frames = overlap_start - ref_start;
            config.dist_trim_frames = overlap_start - dist_start;
            config.ref_start_frame = overlap_start;

            diagnostics.push(format!(
                "  tc offset: ref={}, dist={}",
                ref_info.start_tc.as_deref().unwrap_or("00:00:00:00"),
                dist_info.start_tc.as_deref().unwrap_or("00:00:00:00"),
            ));
            if config.ref_trim_frames > 0 {
                diagnostics.push(format!("  seek ref: {} frames", config.ref_trim_frames));
            }
            if config.dist_trim_frames > 0 {
                diagnostics.push(format!("  seek dist: {} frames", config.dist_trim_frames));
            }
        } else {
            config.ref_start_frame = ref_start;
            diagnostics.push(format!(
                "  tc aligned at {}",
                ref_info.start_tc.as_deref().unwrap_or("00:00:00:00")
            ));
        }
    } else {
        config.ref_start_frame = ref_info.start_tc_frames;
    }

    // Manual frame offset
    if offset_frames != 0 {
        if offset_frames > 0 {
            config.dist_trim_frames += offset_frames;
        } else {
            config.ref_trim_frames += -offset_frames;
            config.ref_start_frame += -offset_frames;
        }
        diagnostics.push(format!("  manual offset: {offset_frames:+} frames"));
    }

    // Convert trim frames to -ss seconds
    if config.ref_trim_frames > 0 {
        config.ref_seek_sec =
            config.ref_trim_frames as f64 * ref_info.fps_den as f64 / ref_info.fps_num as f64;
    }
    if config.dist_trim_frames > 0 {
        config.dist_seek_sec =
            config.dist_trim_frames as f64 * dist_info.fps_den as f64 / dist_info.fps_num as f64;
    }

    // Estimate total frames for progress
    let ref_total = ref_info.nb_frames.unwrap_or(0) as i64;
    let dist_total = dist_info.nb_frames.unwrap_or(0) as i64;
    if ref_total > 0 && dist_total > 0 {
        let ref_avail = ref_total - config.ref_trim_frames;
        let dist_avail = dist_total - config.dist_trim_frames;
        config.total_frames = Some(ref_avail.min(dist_avail).max(0) as u64);
    } else if ref_total > 0 {
        config.total_frames = Some((ref_total - config.ref_trim_frames).max(0) as u64);
    } else if dist_total > 0 {
        config.total_frames = Some((dist_total - config.dist_trim_frames).max(0) as u64);
    }

    Ok((config, tc_fmt))
}

// ─── Diff analysis ──────────────────────────────────────────────────────────

/// Run pixel-difference analysis using FFmpeg's psnr filter.
///
/// Returns a JSON object with mode, frames, metadata — ready for state storage.
pub fn run_diff_analysis(
    ref_path: &str,
    dist_path: &str,
    config: &ComparisonConfig,
    tc_fmt: &TimecodeFormat,
    target_fmt: &str,
    bit_depth: u32,
    progress: Option<ProgressFn>,
    process_handle: ProcessHandle,
) -> Result<Vec<Value>, String> {
    // Stats output file
    let stats_dir = std::env::temp_dir().join(format!("vcompare_diff_{}", std::process::id()));
    std::fs::create_dir_all(&stats_dir)
        .map_err(|e| format!("Failed to create temp dir: {e}"))?;
    let stats_path = stats_dir.join("psnr_stats.txt");
    let stats_path_str = stats_path.to_string_lossy().to_string();

    // Build filter chain
    let ref_chain = format!("format={target_fmt}");
    let mut dist_chain = format!("format={target_fmt}");
    if config.scale_w > 0 {
        dist_chain.push_str(&format!(
            ",scale={}:{}:flags=lanczos",
            config.scale_w, config.scale_h
        ));
    }

    let filter_complex = format!(
        "[0:v]{ref_chain}[ref];[1:v]{dist_chain}[dist];[ref][dist]psnr=stats_file={stats_path_str}"
    );

    // Build command
    let mut args = vec!["ffmpeg".to_string(), "-y".to_string()];
    args.extend(input_args_for(ref_path, config.ref_seek_sec));
    args.extend(input_args_for(dist_path, config.dist_seek_sec));
    args.extend([
        "-filter_complex".into(),
        filter_complex.clone(),
        "-f".into(),
        "null".into(),
        "-".into(),
    ]);

    eprintln!("[vcompare] cmd: {}", args.join(" "));

    // Run ffmpeg
    run_ffmpeg_with_progress(&args[1..], config.total_frames, progress, process_handle)?;

    // Parse stats
    let peak = (1u64 << bit_depth) - 1;
    let frames = parse_psnr_stats(&stats_path_str, tc_fmt, config.ref_start_frame, peak)?;

    // Cleanup temp
    let _ = std::fs::remove_file(&stats_path);
    let _ = std::fs::remove_dir(&stats_dir);

    Ok(frames)
}

// ─── VMAF analysis ──────────────────────────────────────────────────────────

/// Run VMAF analysis using FFmpeg's libvmaf filter.
///
/// Returns parsed metric frames as JSON values.
pub fn run_vmaf_analysis(
    ref_path: &str,
    dist_path: &str,
    config: &mut ComparisonConfig,
    tc_fmt: &TimecodeFormat,
    model: &str,
    hwaccel: Option<&str>,
    subsample: u32,
    want_psnr: bool,
    progress: Option<ProgressFn>,
    diagnostics: &mut Vec<String>,
    process_handle: ProcessHandle,
) -> Result<Vec<Value>, String> {
    // Temp log file
    let log_dir = std::env::temp_dir().join(format!("vcompare_{}", std::process::id()));
    std::fs::create_dir_all(&log_dir)
        .map_err(|e| format!("Failed to create temp dir: {e}"))?;
    let log_path = log_dir.join("vmaf_log.json");
    let log_path_str = log_path.to_string_lossy().to_string();

    let extra_features: Vec<&str> = if want_psnr { vec!["psnr"] } else { vec![] };

    let threads = std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(8);

    // Feature string
    let feature_str = if !extra_features.is_empty() {
        format!(
            ":feature={}",
            extra_features
                .iter()
                .map(|f| format!("name={f}"))
                .collect::<Vec<_>>()
                .join("|")
        )
    } else {
        String::new()
    };

    // Decide GPU vs CPU path
    let use_cuda_vmaf =
        config.use_vmaf_cuda && hwaccel == Some("cuda") && extra_features.is_empty();

    let mut args = vec!["-y".to_string()];

    if use_cuda_vmaf {
        // ── GPU path: libvmaf_cuda ──
        let mut vmaf_opts =
            format!("log_fmt=json:log_path={log_path_str}:model=version={model}");
        if !feature_str.is_empty() {
            vmaf_opts.push_str(&feature_str);
        }
        if subsample > 1 {
            vmaf_opts.push_str(&format!(":n_subsample={subsample}"));
        }
        config.log_subsample = 1;

        let ref_scale = "format=yuv420p".to_string();
        let dist_scale = if config.scale_w > 0 {
            format!(
                "w={}:h={}:format=yuv420p",
                config.scale_w, config.scale_h
            )
        } else {
            "format=yuv420p".to_string()
        };

        let all_filters = format!(
            "[0:v]hwupload_cuda,scale_cuda={ref_scale}[ref];\
             [1:v]hwupload_cuda,scale_cuda={dist_scale}[dist];\
             [ref][dist]libvmaf_cuda={vmaf_opts}"
        );

        args.extend([
            "-init_hw_device".into(),
            "cuda=cu".into(),
            "-filter_hw_device".into(),
            "cu".into(),
        ]);
        args.extend(input_args_for(ref_path, config.ref_seek_sec));
        args.extend(input_args_for(dist_path, config.dist_seek_sec));
        args.extend(["-filter_complex".into(), all_filters, "-f".into(), "null".into(), "-".into()]);
    } else {
        // ── CPU path: libvmaf ──
        let mut vmaf_opts = format!(
            "log_fmt=json:log_path={log_path_str}:model=version={model}:n_threads={threads}"
        );
        if !feature_str.is_empty() {
            vmaf_opts.push_str(&feature_str);
        }
        if subsample > 1 {
            vmaf_opts.push_str(&format!(":n_subsample={subsample}"));
        }
        config.log_subsample = 1;

        let mut ref_chain: Vec<String> = Vec::new();
        let mut dist_chain: Vec<String> = Vec::new();

        if let Some(ref fmt) = config.ref_pixfmt {
            ref_chain.push(format!("format={fmt}"));
        }
        if let Some(ref fmt) = config.dist_pixfmt {
            dist_chain.push(format!("format={fmt}"));
        }
        if config.scale_w > 0 {
            dist_chain.push(format!(
                "scale={}:{}:flags=lanczos",
                config.scale_w, config.scale_h
            ));
        }

        let mut filters_before: Vec<String> = Vec::new();
        let mut ref_label = "0:v".to_string();
        let mut dist_label = "1:v".to_string();

        if !ref_chain.is_empty() {
            filters_before.push(format!("[0:v]{}[ref]", ref_chain.join(",")));
            ref_label = "ref".into();
        }
        if !dist_chain.is_empty() {
            filters_before.push(format!("[1:v]{}[dist]", dist_chain.join(",")));
            dist_label = "dist".into();
        }

        let vmaf_filter = format!("[{ref_label}][{dist_label}]libvmaf={vmaf_opts}");
        let all_filters = if filters_before.is_empty() {
            vmaf_filter
        } else {
            filters_before.push(vmaf_filter);
            filters_before.join(";")
        };

        // Input args with optional hwaccel
        for (path, seek_sec) in [(ref_path, config.ref_seek_sec), (dist_path, config.dist_seek_sec)] {
            if let Some(hw) = hwaccel {
                if !is_concat_manifest(path) {
                    args.extend(["-hwaccel".into(), hw.to_string()]);
                }
            }
            args.extend(input_args_for(path, seek_sec));
        }

        args.extend(["-filter_complex".into(), all_filters, "-f".into(), "null".into(), "-".into()]);
    }

    let fc_display = &args[args.iter().position(|a| a == "-filter_complex").map(|i| i + 1).unwrap_or(0)];
    let fc_short = if fc_display.len() > 80 {
        format!("{}…", &fc_display[..77])
    } else {
        fc_display.clone()
    };
    diagnostics.push(format!("filter: {fc_short}"));

    eprintln!("[vcompare] cmd: ffmpeg {}", args.join(" "));

    // Run ffmpeg
    run_ffmpeg_with_progress(&args, config.total_frames, progress, process_handle)?;

    // Parse VMAF JSON log
    let frames = parse_vmaf_log(
        &log_path_str,
        tc_fmt,
        config.ref_start_frame,
        config.log_subsample,
    )?;

    // Cleanup temp
    let _ = std::fs::remove_file(&log_path);
    let _ = std::fs::remove_dir(&log_dir);

    Ok(frames)
}

// ─── FFmpeg process management ──────────────────────────────────────────────

/// Build -ss/-f/-i args for one input file.
fn input_args_for(path: &str, seek_sec: f64) -> Vec<String> {
    let mut args = Vec::new();
    if seek_sec > 0.0 {
        args.push("-ss".into());
        args.push(format!("{seek_sec:.6}"));
    }
    if is_concat_manifest(path) {
        args.push("-f".into());
        args.push("concat".into());
        args.push("-safe".into());
        args.push("0".into());
    }
    args.push("-i".into());
    args.push(path.into());
    args
}

/// Spawn ffmpeg, stream stderr for progress, wait for completion.
///
/// The process handle allows external cancellation (e.g. app quit).
/// FFmpeg writes progress updates with `\r` (no `\n`), so we read bytes
/// and split on both `\r` and `\n`.
fn run_ffmpeg_with_progress(
    args: &[String],
    total_frames: Option<u64>,
    progress: Option<ProgressFn>,
    process_handle: ProcessHandle,
) -> Result<(), String> {
    let mut child = Command::new("ffmpeg")
        .args(args)
        .stderr(Stdio::piped())
        .stdout(Stdio::null())
        .spawn()
        .map_err(|e| format!("Failed to spawn ffmpeg: {e}"))?;

    // Take stderr before storing child — the Child retains pid for kill/wait
    let stderr = child.stderr.take().ok_or("Failed to get ffmpeg stderr")?;

    // Store child in handle for external cancellation
    *process_handle.lock().unwrap() = Some(child);

    let frame_re = Regex::new(r"frame=\s*(\d+)").unwrap();
    let mut last_reported: i64 = -1;
    let mut last_progress_time = Instant::now();
    let mut stderr_tail: VecDeque<String> = VecDeque::with_capacity(20);

    // Read stderr byte-by-byte, splitting on both \r and \n.
    // FFmpeg uses \r for progress counter updates (same-line overwrite).
    let mut reader = BufReader::new(stderr);
    let mut line_buf = Vec::with_capacity(256);

    loop {
        let mut byte = [0u8; 1];
        match std::io::Read::read(&mut reader, &mut byte) {
            Ok(0) => break, // EOF
            Ok(_) => {
                if byte[0] == b'\r' || byte[0] == b'\n' {
                    if !line_buf.is_empty() {
                        let line = String::from_utf8_lossy(&line_buf).to_string();
                        line_buf.clear();

                        if stderr_tail.len() >= 20 {
                            stderr_tail.pop_front();
                        }
                        stderr_tail.push_back(line.clone());

                        if let Some(caps) = frame_re.captures(&line) {
                            if let Some(total) = total_frames {
                                if let Ok(current) = caps[1].parse::<u64>() {
                                    if current as i64 != last_reported {
                                        last_reported = current as i64;
                                        let now = Instant::now();
                                        if now.duration_since(last_progress_time).as_millis() >= 250
                                        {
                                            last_progress_time = now;
                                            if let Some(ref cb) = progress {
                                                cb(current, total);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    line_buf.push(byte[0]);
                }
            }
            Err(e) => {
                eprintln!("[vcompare] stderr read error: {e}");
                break;
            }
        }
    }

    // Wait for process to finish
    let mut child_opt = process_handle.lock().unwrap().take();
    let status = match child_opt.as_mut() {
        Some(c) => c.wait().map_err(|e| format!("Failed to wait for ffmpeg: {e}"))?,
        None => return Err("ffmpeg process was killed externally".into()),
    };

    // Final progress
    if last_reported > 0 {
        if let (Some(total), Some(ref cb)) = (total_frames, &progress) {
            cb(total, total);
        }
    }

    if !status.success() {
        let tail: String = stderr_tail.into_iter().collect::<Vec<_>>().join("\n");
        return Err(format!(
            "FFmpeg exited with code {}\n\n{tail}",
            status.code().unwrap_or(-1)
        ));
    }

    Ok(())
}

// ─── Result parsing ─────────────────────────────────────────────────────────

/// Parse psnr filter stats_file output into frame JSON values.
///
/// Format per line: `n:1 mse_avg:0.00 mse_y:0.00 mse_u:0.00 mse_v:0.00 ...`
fn parse_psnr_stats(
    stats_path: &str,
    tc_fmt: &TimecodeFormat,
    ref_start_frame: i64,
    _peak: u64,
) -> Result<Vec<Value>, String> {
    let content = std::fs::read_to_string(stats_path)
        .map_err(|e| format!("Failed to read psnr stats: {e}"))?;

    let kv_re = Regex::new(r"(\w+):([\d.inf]+)").unwrap();
    let mut frames = Vec::new();

    for line in content.lines() {
        let line = line.trim();
        if line.is_empty() {
            continue;
        }

        let pairs: std::collections::HashMap<&str, &str> = kv_re
            .captures_iter(line)
            .map(|c| (c.get(1).unwrap().as_str(), c.get(2).unwrap().as_str()))
            .collect();

        let n = match pairs.get("n").and_then(|s| s.parse::<i64>().ok()) {
            Some(n) => n,
            None => continue,
        };

        let fn_ = n - 1; // psnr filter is 1-indexed
        let display_frame = fn_ + ref_start_frame;

        let mse_y = parse_float_or_zero(pairs.get("mse_y").copied());
        let mse_u = parse_float_or_zero(pairs.get("mse_u").copied());
        let mse_v = parse_float_or_zero(pairs.get("mse_v").copied());

        let rms_y = if mse_y > 0.0 { mse_y.sqrt() } else { 0.0 };
        let rms_u = if mse_u > 0.0 { mse_u.sqrt() } else { 0.0 };
        let rms_v = if mse_v > 0.0 { mse_v.sqrt() } else { 0.0 };

        frames.push(serde_json::json!({
            "frame": display_frame,
            "tc": tc_fmt.frame_to_tc(display_frame),
            "diff_y": round4(rms_y),
            "diff_u": round4(rms_u),
            "diff_v": round4(rms_v),
        }));
    }

    Ok(frames)
}

/// Parse a VMAF JSON log into frame values.
fn parse_vmaf_log(
    log_path: &str,
    tc_fmt: &TimecodeFormat,
    ref_start_frame: i64,
    subsample: u32,
) -> Result<Vec<Value>, String> {
    let content = std::fs::read_to_string(log_path)
        .map_err(|e| format!("Failed to read VMAF log: {e}"))?;

    let data: Value =
        serde_json::from_str(&content).map_err(|e| format!("Failed to parse VMAF JSON: {e}"))?;

    let all_frames = data
        .get("frames")
        .and_then(|v| v.as_array())
        .ok_or("No 'frames' array in VMAF log")?;

    let mut frames = Vec::new();

    for entry in all_frames {
        let fn_ = entry
            .get("frameNum")
            .and_then(|v| v.as_i64())
            .unwrap_or(0);

        let metrics = entry.get("metrics").and_then(|v| v.as_object());

        // PSNR key varies by libvmaf version
        let psnr = metrics
            .and_then(|m| {
                m.get("psnr_y")
                    .and_then(|v| v.as_f64())
                    .or_else(|| m.get("psnr_y (mean)").and_then(|v| v.as_f64()))
                    .or_else(|| {
                        m.iter()
                            .find(|(k, v)| k.to_lowercase().contains("psnr") && v.is_f64())
                            .and_then(|(_, v)| v.as_f64())
                    })
            });

        let vmaf = metrics.and_then(|m| m.get("vmaf").and_then(|v| v.as_f64()));

        let real_frame = fn_ * subsample as i64;
        let display_frame = real_frame + ref_start_frame;

        frames.push(serde_json::json!({
            "frame": display_frame,
            "tc": tc_fmt.frame_to_tc(display_frame),
            "vmaf": vmaf.map(|v| round3(v)),
            "psnr": psnr.map(|v| round3(v)),
        }));
    }

    Ok(frames)
}

// ─── Helpers ────────────────────────────────────────────────────────────────

fn parse_float_or_zero(s: Option<&str>) -> f64 {
    s.and_then(|s| {
        if s == "inf" || s == "-inf" {
            None
        } else {
            s.parse::<f64>().ok()
        }
    })
    .unwrap_or(0.0)
}

fn round3(v: f64) -> f64 {
    (v * 1000.0).round() / 1000.0
}

fn round4(v: f64) -> f64 {
    (v * 10000.0).round() / 10000.0
}
