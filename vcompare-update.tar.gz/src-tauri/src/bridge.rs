//! Tauri commands — the frontend calls these via `invoke()`.
//! Each command forwards to the Python sidecar via JSON-RPC.
//!
//! The pattern is intentionally thin: the Rust layer is a typed passthrough.
//! Business logic lives in Python. Rust handles typing, error mapping,
//! the file dialog (which needs native OS access), and recent analysis storage.
//!
//! IMPORTANT: Param structs derive both Deserialize (from frontend) AND
//! Serialize (to JSON-RPC). We use `serde_json::to_value()` to forward
//! them — never hand-build `json!({})` for param structs, as that silently
//! drops fields when the struct is updated.

use crate::engine;
use crate::sidecar::Sidecar;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use tauri::State;

/// Shared sidecar handle, managed as Tauri state.
pub struct SidecarState(pub Arc<Sidecar>);

// ─── Typed param structs for Tauri IPC ──────────────────────────────────────

/// Parameters for the `analyze` command.
///
/// Derives both Deserialize (Tauri IPC from frontend) and Serialize
/// (forwarded as JSON-RPC params to Python). `skip_serializing_if`
/// keeps the JSON clean — Python uses `.get(key, default)` for omitted fields.
#[derive(Deserialize, Serialize)]
pub struct AnalyzeParams {
    pub reference: String,
    pub distorted: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub mode: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub model: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub hwaccel: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub sync: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub offset: Option<i64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub subsample: Option<u32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub psnr: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub log_path: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub force: Option<bool>,
}

/// Parameters for the `get_frames` command.
#[derive(Deserialize, Serialize)]
pub struct GetFramesParams {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub offset: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub limit: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub sort: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub ascending: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub filter_metric: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub filter_below: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub filter_above: Option<f64>,
}

// ─── Recent analyses ────────────────────────────────────────────────────────

const MAX_RECENTS: usize = 20;

#[derive(Clone, Serialize, Deserialize)]
pub struct RecentEntry {
    pub ref_path: String,
    pub dist_path: String,
    pub cache_path: String,
    pub mode: String,
    pub frame_count: u64,
    /// Unix epoch seconds
    pub timestamp: u64,
}

/// Persistent store for recent analyses, backed by a JSON file.
pub struct RecentsState {
    path: PathBuf,
    entries: Mutex<Vec<RecentEntry>>,
}

impl RecentsState {
    pub fn new(data_dir: PathBuf) -> Self {
        let _ = std::fs::create_dir_all(&data_dir);
        let path = data_dir.join("recents.json");
        let entries = Self::load_file(&path);
        Self {
            path,
            entries: Mutex::new(entries),
        }
    }

    fn load_file(path: &PathBuf) -> Vec<RecentEntry> {
        match std::fs::read_to_string(path) {
            Ok(data) => serde_json::from_str(&data).unwrap_or_default(),
            Err(_) => Vec::new(),
        }
    }

    fn save(&self, entries: &[RecentEntry]) {
        if let Ok(json) = serde_json::to_string_pretty(entries) {
            let _ = std::fs::write(&self.path, json);
        }
    }
}

// ─── Helper: forward RPC call with error mapping ────────────────────────────

async fn rpc_call(
    sidecar: &State<'_, SidecarState>,
    method: &str,
    params: Value,
) -> Result<Value, String> {
    sidecar
        .0
        .call(method, params)
        .await
        .map_err(|e| e.message)
}

// ─── Commands ───────────────────────────────────────────────────────────────

#[tauri::command]
pub async fn ping(sidecar: State<'_, SidecarState>) -> Result<Value, String> {
    rpc_call(&sidecar, "ping", json!({})).await
}

#[tauri::command]
pub async fn detect_capabilities() -> Result<engine::types::Capabilities, String> {
    // Synchronous ffmpeg calls — run off the async executor
    tokio::task::spawn_blocking(engine::probe::detect_capabilities)
        .await
        .map_err(|e| format!("Task join error: {e}"))
}

#[tauri::command]
pub async fn probe_file(path: String) -> Result<engine::types::ProbeResult, String> {
    // Synchronous ffprobe call — run off the async executor
    tokio::task::spawn_blocking(move || engine::probe::probe_file(&path))
        .await
        .map_err(|e| format!("Task join error: {e}"))?
}

#[tauri::command]
pub async fn check_cache(
    sidecar: State<'_, SidecarState>,
    reference: String,
    distorted: String,
) -> Result<Value, String> {
    rpc_call(
        &sidecar,
        "check_cache",
        json!({ "reference": reference, "distorted": distorted }),
    )
    .await
}

#[tauri::command]
pub async fn load_saved_analysis(
    sidecar: State<'_, SidecarState>,
    path: String,
) -> Result<Value, String> {
    rpc_call(&sidecar, "load_saved_analysis", json!({ "path": path })).await
}

#[tauri::command]
pub async fn analyze(
    sidecar: State<'_, SidecarState>,
    params: AnalyzeParams,
) -> Result<Value, String> {
    // Serialize the entire struct — never hand-build json!({}) for param structs.
    let params_value = serde_json::to_value(params)
        .map_err(|e| format!("Failed to serialize analyze params: {e}"))?;
    rpc_call(&sidecar, "analyze", params_value).await
}

#[tauri::command]
pub async fn get_frames(
    sidecar: State<'_, SidecarState>,
    params: GetFramesParams,
) -> Result<Value, String> {
    let params_value = serde_json::to_value(params)
        .map_err(|e| format!("Failed to serialize get_frames params: {e}"))?;
    rpc_call(&sidecar, "get_frames", params_value).await
}

#[tauri::command]
pub async fn get_metric_series(
    sidecar: State<'_, SidecarState>,
    metric: String,
) -> Result<Value, String> {
    rpc_call(
        &sidecar,
        "get_metric_series",
        json!({ "metric": metric }),
    )
    .await
}

// ─── mpv commands ───────────────────────────────────────────────────────────

#[tauri::command]
pub async fn mpv_launch(sidecar: State<'_, SidecarState>) -> Result<Value, String> {
    rpc_call(&sidecar, "mpv.launch", json!({})).await
}

#[tauri::command]
pub async fn mpv_seek(sidecar: State<'_, SidecarState>, frame: u64) -> Result<Value, String> {
    rpc_call(&sidecar, "mpv.seek", json!({ "frame": frame })).await
}

#[tauri::command]
pub async fn mpv_step(
    sidecar: State<'_, SidecarState>,
    direction: String,
) -> Result<Value, String> {
    rpc_call(&sidecar, "mpv.step", json!({ "direction": direction })).await
}

#[tauri::command]
pub async fn mpv_toggle_pause(sidecar: State<'_, SidecarState>) -> Result<Value, String> {
    rpc_call(&sidecar, "mpv.toggle_pause", json!({})).await
}

#[tauri::command]
pub async fn mpv_kill(sidecar: State<'_, SidecarState>) -> Result<Value, String> {
    rpc_call(&sidecar, "mpv.kill", json!({})).await
}

// ─── Export ─────────────────────────────────────────────────────────────────

#[tauri::command]
pub async fn export_csv(
    sidecar: State<'_, SidecarState>,
    path: Option<String>,
) -> Result<Value, String> {
    rpc_call(&sidecar, "export_csv", json!({ "path": path })).await
}

// ─── Recent analyses ────────────────────────────────────────────────────────

#[tauri::command]
pub async fn get_recents(
    recents: State<'_, RecentsState>,
) -> Result<Vec<RecentEntry>, String> {
    let entries = recents.entries.lock().unwrap();
    Ok(entries.clone())
}

#[tauri::command]
pub async fn add_recent(
    recents: State<'_, RecentsState>,
    entry: RecentEntry,
) -> Result<(), String> {
    let mut entries = recents.entries.lock().unwrap();

    // Remove existing entry with same cache_path (dedup)
    entries.retain(|e| e.cache_path != entry.cache_path);

    // Prepend new entry (most recent first)
    entries.insert(0, entry);

    // Cap at MAX_RECENTS
    entries.truncate(MAX_RECENTS);

    recents.save(&entries);
    Ok(())
}

#[tauri::command]
pub async fn clear_recents(recents: State<'_, RecentsState>) -> Result<(), String> {
    let mut entries = recents.entries.lock().unwrap();
    entries.clear();
    recents.save(&entries);
    Ok(())
}
