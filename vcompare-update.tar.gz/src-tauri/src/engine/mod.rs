//! Native analysis engine — replaces the Python sidecar.
//!
//! Phase 1: types, timecode math, pixel format negotiation
//! Phase 2: ffprobe wrappers, capability detection

pub mod pixfmt;
pub mod probe;
pub mod timecode;
pub mod types;

// Re-export the most-used types for convenience
pub use pixfmt::{choose_common_pixfmt, choose_diff_pixfmt};
pub use probe::{
    detect_hwaccel, detect_vmaf_cuda, ffprobe_json, get_video_info, is_concat_manifest,
};
pub use timecode::{detect_timecode_format, tc_string_to_frames, TcType, TimecodeFormat};
pub use types::{ComparisonConfig, MetricFrame, VideoInfo};
