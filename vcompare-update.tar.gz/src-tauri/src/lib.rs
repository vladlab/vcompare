mod bridge;
mod engine;
mod sidecar;

use bridge::{RecentsState, SidecarState};
use std::env;
use std::process::Command;
use tauri::{Emitter, Manager};

/// In dev mode: spawn `python3 sidecar/vcompare_engine.py`
/// In prod mode: spawn the compiled binary next to the app executable.
fn build_sidecar_command() -> (Command, String) {
    // Explicit override — always wins
    if let Ok(path) = env::var("VCOMPARE_SIDECAR") {
        let cmd = Command::new(&path);
        return (cmd, format!("{path} (env override)"));
    }

    // Dev mode: use Python interpreter + script
    #[cfg(dev)]
    {
        let script = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .parent()
            .unwrap()
            .join("sidecar")
            .join("vcompare_engine.py");

        let python = find_python();
        let desc = format!("{python} {}", script.display());
        let mut cmd = Command::new(&python);
        cmd.arg(script);
        return (cmd, desc);
    }

    // Production: compiled binary next to the app executable
    #[cfg(not(dev))]
    {
        // Tauri bundles externalBin next to the app binary
        let exe_dir = env::current_exe()
            .expect("Failed to get exe path")
            .parent()
            .unwrap()
            .to_path_buf();

        // Try with target triple suffix (Tauri convention)
        let triple = env!("TAURI_ENV_TARGET_TRIPLE");
        let candidates = [
            exe_dir.join(format!("vcompare_engine-{triple}")),
            exe_dir.join("vcompare_engine"),
        ];

        for path in &candidates {
            if path.exists() {
                let desc = format!("{}", path.display());
                let cmd = Command::new(path);
                return (cmd, desc);
            }
        }

        // Fallback: maybe Python is available
        let script_candidates = [
            exe_dir.join("sidecar").join("vcompare_engine.py"),
            exe_dir.join("vcompare_engine.py"),
        ];

        for script in &script_candidates {
            if script.exists() {
                let python = find_python();
                let desc = format!("{python} {} (fallback)", script.display());
                let mut cmd = Command::new(&python);
                cmd.arg(script);
                return (cmd, desc);
            }
        }

        panic!(
            "Cannot find sidecar binary. Looked for: {}",
            candidates
                .iter()
                .map(|p| p.display().to_string())
                .collect::<Vec<_>>()
                .join(", ")
        );
    }
}

/// Locate Python 3 interpreter.
fn find_python() -> String {
    if let Ok(p) = env::var("VCOMPARE_PYTHON") {
        return p;
    }

    for candidate in &["python3", "python"] {
        if let Ok(output) = Command::new(candidate).arg("--version").output() {
            if output.status.success() {
                let version = String::from_utf8_lossy(&output.stdout);
                let version_err = String::from_utf8_lossy(&output.stderr);
                if version.contains("Python 3") || version_err.contains("Python 3") {
                    return candidate.to_string();
                }
            }
        }
    }

    "python3".to_string()
}

/// Build the native menu bar.
fn build_menu(app: &tauri::App) -> Result<(), Box<dyn std::error::Error>> {
    use tauri::menu::{Menu, MenuItem, PredefinedMenuItem, Submenu};

    let new_analysis = MenuItem::with_id(
        app,
        "new-analysis",
        "New Analysis",
        true,
        Some("CmdOrCtrl+N"),
    )?;
    let open_recent = MenuItem::with_id(
        app,
        "open-recent",
        "Recent Analyses…",
        true,
        Some("CmdOrCtrl+Shift+O"),
    )?;
    let export = MenuItem::with_id(
        app,
        "export-csv",
        "Export CSV…",
        true,
        Some("CmdOrCtrl+Shift+E"),
    )?;
    let sep = PredefinedMenuItem::separator(app)?;
    let quit = PredefinedMenuItem::quit(app, Some("Quit"))?;

    let file_menu = Submenu::with_items(
        app,
        "File",
        true,
        &[&new_analysis, &open_recent, &export, &sep, &quit],
    )?;

    let menu = Menu::with_items(app, &[&file_menu])?;
    app.set_menu(menu)?;

    Ok(())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    env_logger::init();

    // ── WebKitGTK workarounds ──────────────────────────────────────────────
    if env::var("WEBKIT_DISABLE_DMABUF_RENDERER").is_err() {
        let has_nvidia = std::fs::read_to_string("/proc/driver/nvidia/version").is_ok()
            || std::path::Path::new("/dev/nvidiactl").exists();
        if has_nvidia {
            env::set_var("WEBKIT_DISABLE_DMABUF_RENDERER", "1");
            log::info!("NVIDIA detected — set WEBKIT_DISABLE_DMABUF_RENDERER=1");
        }
    }

    if env::var("WEBKIT_DISABLE_COMPOSITING_MODE").is_err() {
        if env::var("WAYLAND_DISPLAY").is_ok() {
            env::set_var("WEBKIT_DISABLE_COMPOSITING_MODE", "1");
            log::info!("Wayland detected — set WEBKIT_DISABLE_COMPOSITING_MODE=1");
        }
    }

    let app = tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_shell::init())
        .setup(|app| {
            // ── Menu ──
            if let Err(e) = build_menu(app) {
                log::error!("Failed to build menu: {e}");
            }

            // Handle menu events → emit to frontend
            app.on_menu_event(|app_handle, event| {
                let id = event.id().as_ref();
                match id {
                    "new-analysis" | "open-recent" | "export-csv" => {
                        if let Err(e) = app_handle.emit("menu-event", id) {
                            log::error!("Failed to emit menu event {id}: {e}");
                        }
                    }
                    _ => {}
                }
            });

            // ── Recent analyses store ──
            let data_dir = app.path().app_data_dir().unwrap_or_else(|_| {
                std::path::PathBuf::from(".")
            });
            let recents = RecentsState::new(data_dir);
            app.manage(recents);

            // ── Sidecar ──
            let (cmd, desc) = build_sidecar_command();
            log::info!("Spawning sidecar: {desc}");

            let sidecar = sidecar::Sidecar::spawn(app.handle(), cmd).map_err(|e| {
                log::error!("Sidecar spawn failed: {e}");
                Box::<dyn std::error::Error>::from(e)
            })?;

            // Verify sidecar is alive
            let sc = sidecar.clone();
            tauri::async_runtime::spawn(async move {
                match sc.call("ping", serde_json::json!({})).await {
                    Ok(resp) => log::info!("Sidecar alive: {resp}"),
                    Err(e) => log::error!("Sidecar ping failed: {e}"),
                }
            });

            app.manage(SidecarState(sidecar));
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            bridge::ping,
            bridge::detect_capabilities,
            bridge::probe_file,
            bridge::check_cache,
            bridge::load_saved_analysis,
            bridge::analyze,
            bridge::get_frames,
            bridge::get_metric_series,
            bridge::mpv_launch,
            bridge::mpv_seek,
            bridge::mpv_step,
            bridge::mpv_toggle_pause,
            bridge::mpv_kill,
            bridge::export_csv,
            bridge::get_recents,
            bridge::add_recent,
            bridge::clear_recents,
        ])
        .build(tauri::generate_context!())
        .expect("error while building tauri application");

    // Use .run() with callback so we can explicitly clean up on exit.
    // Drop alone isn't reliable — Tauri may not drop managed state before
    // the process terminates, leaving mpv orphaned.
    app.run(|app_handle, event| {
        if let tauri::RunEvent::Exit = event {
            log::info!("App exiting — killing sidecar");
            if let Some(state) = app_handle.try_state::<SidecarState>() {
                state.0.kill();
            }
        }
    });
}
